"""Exact skipped-case CUDA acceptance on the approved third migration cutoff."""
import argparse,hashlib,json,time
from pathlib import Path


def run_batch(guard,batch,budget):
    import os,signal,subprocess,sys,threading,platform
    import xml.etree.ElementTree as ET
    key=batch['id']
    if not guard.put(key,{'started':time.time()},skip_if_exists=True):
        raise RuntimeError('Duplicate batch execution refused: '+key)
    root=Path('/workspace');os.chdir(root)
    manifest=json.loads((root/'atlas-upload-manifest.json').read_text())
    def verify():
        for name,digest in manifest['files'].items():
            assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    verify()
    events=Path('/tmp/atlas-events-'+key+'.jsonl');junit=Path('/tmp/atlas-junit-'+key+'.xml')
    env=dict(os.environ,B2_TEST_CUDA='1',B2_TEST_CUDA_TRAIN='1',B2_TRAIN_CUDA_DEVICE='0',B2_TEST_MPI='1',PMIX_MCA_gds='hash',OMPI_ALLOW_RUN_AS_ROOT='1',OMPI_ALLOW_RUN_AS_ROOT_CONFIRM='1',OMPI_MCA_rmaps_base_oversubscribe='1',B2_TEST_CHILD_TIMEOUT='900',B2_RUNNER='/workspace/brian2-rust/target/release/b2-runner',B2_TRAIN_RUNNER='/workspace/brian2-rust/target/release/b2-train',ATLAS_EVENTS=str(events))
    wrapper='''import json,sys,os,pytest
class Reports:
    def pytest_runtest_logreport(self,report):
        with open(os.environ['ATLAS_EVENTS'],'a') as stream:
            stream.write(json.dumps(dict(nodeid=report.nodeid,when=report.when,outcome=report.outcome,duration=report.duration))+'\\n')
raise SystemExit(pytest.main(sys.argv[1:],plugins=[Reports()]))
'''
    command=[sys.executable,'-u','-c',wrapper,'-v','--tb=short','--maxfail=3','--junitxml='+str(junit),*['brian2-rust/tests/'+n for n in batch['nodes']]]
    report={'batch':batch,'started_unix':time.time(),'gpu':subprocess.check_output(['nvidia-smi'],text=True),'python':sys.version,'platform':platform.platform(),'command':command,'nvcc':subprocess.check_output(['nvcc','--version'],text=True),'binary_sha256':{n:hashlib.sha256((root/'brian2-rust/target/release'/n).read_bytes()).hexdigest() for n in ['b2-runner','b2-train']}}
    lines=[];timed_out=False
    with subprocess.Popen(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True) as process:
        def capture():
            for line in process.stdout:lines.append(line);print(line,end='',flush=True)
        reader=threading.Thread(target=capture,daemon=True);reader.start()
        try:process.wait(timeout=min(1800,budget))
        except subprocess.TimeoutExpired:
            timed_out=True;os.killpg(process.pid,signal.SIGKILL);process.wait()
        reader.join(timeout=10)
        if reader.is_alive():raise RuntimeError('Output reader did not close')
    report.update(exit_code=process.returncode,timeout=timed_out,stdout=''.join(lines),ended_unix=time.time(),events=[json.loads(s) for s in events.read_text().splitlines()] if events.exists() else [],junit=junit.read_text() if junit.exists() else '')
    cases=ET.fromstring(report['junit']).findall('.//testcase') if report['junit'] else []
    report['cases']=[{'node':t.get('classname').split('.')[-1]+'.py::'+t.get('name'),'outcome':'failed' if t.find('failure') is not None or t.find('error') is not None else 'skipped' if t.find('skipped') is not None else 'passed'} for t in cases]
    report['passed']=process.returncode==0 and not timed_out and len(cases)==len(batch['nodes']) and {t['node'] for t in report['cases']}==set(batch['nodes']) and all(t['outcome']=='passed' for t in report['cases'])
    verify();report['source_hashes_unchanged']=True;guard.put(key+'-report',report)
    return report


def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--only',action='append');a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False);manifest=json.loads((a.source/'atlas-upload-manifest.json').read_text())
    batches=[b for b in manifest['batches'] if not a.only or b['id'] in a.only]
    import modal
    image=(modal.Image.from_registry('nvidia/cuda:12.8.1-devel-ubuntu24.04',add_python='3.12')
        .entrypoint([]).apt_install('curl','clang','build-essential')
        .run_commands("curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain 1.98.1")
        .env({'PATH':'/root/.cargo/bin:/usr/local/cuda/bin:/usr/local/bin:/usr/bin:/bin','PYTHONPATH':'/workspace/brian2-rust/python:/workspace','MPLCONFIGDIR':'/tmp/matplotlib','PYTHONDONTWRITEBYTECODE':'1','CARGO_BUILD_JOBS':'2','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
        .pip_install('numpy==2.2.6','cupy-cuda12x==13.6.0','pytest==8.4.1','cython==3.0.12','sympy==1.14.0','pyparsing==3.2.3','jinja2==3.1.6','setuptools==80.9.0','packaging==25.0','setuptools_scm==8.3.1','wheel==0.45.1')
        .apt_install('libopenmpi-dev','openmpi-bin').pip_install('scipy==1.15.3')
        .add_local_dir(a.source,'/workspace',copy=True)
        .run_commands('cargo build --release --locked --bin b2-runner --bin b2-train --manifest-path /workspace/brian2-rust/Cargo.toml','python -m pip install --no-deps --no-build-isolation -e /workspace')
        .add_local_file(Path(__file__),'/root/atlas_modal_cuda_followup.py'))
    app=modal.App('atlas-cutoff-cuda-followup',include_source=False)
    run=app.function(image=image,gpu='L4',cpu=4,memory=8192,max_containers=1,timeout=1920,retries=0)(run_batch)
    launch={'started_unix':time.time(),'source_head':manifest['source_head'],'resource_scope':manifest['resource_scope'],'manifest_sha256':hashlib.sha256((a.source/'atlas-upload-manifest.json').read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'batches':batches}
    (a.output/'launch.json').write_text(json.dumps(launch,indent=2)+'\n');results=[];used=0;error=None;app_id=None
    with modal.enable_output(),modal.Dict.ephemeral() as guard:
        try:
            with app.run():
                app_id=app.app_id;(a.output/'app.json').write_text(json.dumps({'app_id':app_id})+'\n')
                for batch in batches:
                    if used>=7200:raise RuntimeError('GPU test time budget exhausted')
                    print('BATCH_START '+batch['id'],flush=True)
                    report=run.remote(guard,batch,7200-used);used+=report['ended_unix']-report['started_unix'];results.append(report)
                    (a.output/(batch['id']+'.json')).write_text(json.dumps(report,indent=2)+'\n')
                    (a.output/(batch['id']+'.xml')).write_text(report['junit'])
                    print('BATCH_RESULT '+json.dumps({'id':batch['id'],'passed':report['passed'],'count':len(report['cases']),'seconds':report['ended_unix']-report['started_unix']}),flush=True)
                    if not report['passed']:break
        except Exception as exc:
            error={'type':type(exc).__name__,'message':str(exc)}
            # Preserve evidence even if delivery fails after the remote function completes.
            for b in batches:
                if not (a.output/(b['id']+'.json')).exists():
                    saved=guard.get(b['id']+'-report')
                    if saved:(a.output/(b['id']+'.json')).write_text(json.dumps(saved,indent=2)+'\n')
    summary={'app_id':app_id,'passed':len(results)==len(batches) and all(r['passed'] for r in results) and not error,'error':error,'batches_completed':len(results),'batches_expected':len(batches),'test_seconds':used,'completed_unix':time.time(),'results':[{'id':r['batch']['id'],'passed':r['passed'],'cases':r['cases']} for r in results]}
    (a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('FINAL '+json.dumps({k:v for k,v in summary.items() if k!='results'}),flush=True)
    raise SystemExit(0 if summary['passed'] else 1)

if __name__=='__main__':main()
